coba di running aja dulu 
1. langsung aja run docker-compose up 
2. buka url localhost:8080 untuk phpmyadmin nya 
3. import dat dari inventa.sql ke phpmyadmin 
4. buka url localhost:8000 untuk website inventa nya 
5. harusnnya udah bisa jalan 

terus masih ada banyak point yang kurang nya sih , kayak nambah message queue atau apa gitu 
terus aku juga masih belum tau service top level itu gimana dll , coba aja itu di runing dulu yaa 