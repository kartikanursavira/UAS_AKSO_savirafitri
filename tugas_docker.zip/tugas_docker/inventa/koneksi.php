<?php
	$host ='mysqldb';
	$user ='user';
	$pass ='password';
	$db ='inventa';
	$conn =mysqli_connect($host, $user, $pass, $db);
	if($conn){
		echo "Koneksi Berhasil";
	}else {
		echo "Koneksi gagal";
	}
	mysqli_select_db($conn, $db);
?>





